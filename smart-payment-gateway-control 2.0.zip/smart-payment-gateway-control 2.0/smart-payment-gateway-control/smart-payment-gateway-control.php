<?php
/**
 * Plugin Name:       Smart Payment Gateway Control
 * Plugin URI:        https://github.com/fahadkhalid211/Smart-Payment-Gateway-Control
 * Description:       Conditionally disable WooCommerce payment methods based on product, category, cart total, user role, shipping method, country, or order quantity.
 * Version:           2.0.0
 * Author:            Fahad Khalid
 * Author URI:        https://linktr.ee/fahadkhalid211
 * Text Domain:       smart-payment-gateway-control
 * Domain Path:       /languages
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Requires at least: 5.8
 * Tested up to:      6.9
 * Requires PHP:      7.4
 * WC requires at least: 6.0
 * WC tested up to:   9.9
 *
 * @package DisablePaymentByProduct
 */

defined( 'ABSPATH' ) || exit;

add_action(
	'before_woocommerce_init',
	static function () {
		if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
			\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
		}
	}
);

if ( ! class_exists( 'SPGC_Plugin' ) ) :

final class SPGC_Plugin {

	const OPTION_KEY   = 'spgc_rules';
	const MENU_SLUG    = 'spgc-settings';
	const NONCE_NAME   = 'spgc_nonce';
	const NONCE_ACTION = 'spgc_save_rules';
	const VERSION      = '2.0.0';

	private static $instance = null;

	public static function get_instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		add_action( 'admin_menu',                             array( $this, 'register_menu' ) );
		add_action( 'admin_enqueue_scripts',                  array( $this, 'enqueue_assets' ) );
		add_filter( 'woocommerce_available_payment_gateways', array( $this, 'filter_gateways' ) );
		add_action( 'wp_ajax_spgc_search_products',         array( $this, 'ajax_products' ) );
		add_action( 'wp_ajax_spgc_search_shipping',         array( $this, 'ajax_shipping' ) );
	}

	/* =========================================================================
	 * MENU & ASSETS
	 * ====================================================================== */

	public function register_menu() {
		add_submenu_page(
			'woocommerce',
			esc_html__( 'Payment Rules', 'smart-payment-gateway-control' ),
			esc_html__( 'Payment Rules', 'smart-payment-gateway-control' ),
			'manage_woocommerce',
			self::MENU_SLUG,
			array( $this, 'render_page' )
		);
	}

	public function enqueue_assets( $hook ) {
		if ( 'woocommerce_page_' . self::MENU_SLUG !== $hook ) {
			return;
		}
		wp_enqueue_style( 'select2' );
		wp_enqueue_script( 'select2' );
		wp_enqueue_script( 'jquery' );
	}

	/* =========================================================================
	 * AJAX
	 * ====================================================================== */

	public function ajax_products() {
		check_ajax_referer( 'spgc_ajax', 'security' );
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( null, 403 );
		}
		$q = isset( $_GET['q'] ) ? sanitize_text_field( wp_unslash( $_GET['q'] ) ) : '';
		$query = new WP_Query( array(
			'post_type'      => array( 'product', 'product_variation' ),
			'post_status'    => 'publish',
			's'              => $q,
			'posts_per_page' => 20,
			'fields'         => 'ids',
		) );
		$results = array();
		foreach ( $query->posts as $id ) {
			$p = wc_get_product( $id );
			if ( $p ) {
				$results[] = array( 'id' => $id, 'text' => wp_strip_all_tags( $p->get_formatted_name() ) );
			}
		}
		wp_send_json( array( 'results' => $results ) );
	}

	public function ajax_shipping() {
		check_ajax_referer( 'spgc_ajax', 'security' );
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( null, 403 );
		}
		$methods = array();
		foreach ( WC_Shipping_Zones::get_zones() as $zd ) {
			$zone = new WC_Shipping_Zone( $zd['zone_id'] );
			foreach ( $zone->get_shipping_methods( true ) as $inst ) {
				$methods[] = array( 'id' => $inst->get_rate_id(), 'text' => $zd['zone_name'] . ' — ' . $inst->get_title() );
			}
		}
		$z0 = new WC_Shipping_Zone( 0 );
		foreach ( $z0->get_shipping_methods( true ) as $inst ) {
			$methods[] = array( 'id' => $inst->get_rate_id(), 'text' => esc_html__( 'Rest of World', 'smart-payment-gateway-control' ) . ' — ' . $inst->get_title() );
		}
		wp_send_json( array( 'results' => $methods ) );
	}

	/* =========================================================================
	 * ADMIN PAGE
	 * ====================================================================== */

	public function render_page() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( esc_html__( 'No permission.', 'smart-payment-gateway-control' ) );
		}

		$saved = false;
		if (
			isset( $_POST[ self::NONCE_NAME ] ) &&
			wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST[ self::NONCE_NAME ] ) ), self::NONCE_ACTION )
		) {
			$this->save_rules();
			$saved = true;
		}

		$rules      = $this->get_rules();
		$gateways   = $this->get_gateway_options();
		$categories = $this->get_category_options();
		$roles      = $this->get_role_options();
		$countries  = $this->get_country_options();
		$cond_types = $this->get_condition_types();
		$op_map     = $this->get_operators_map();
		$op_labels  = $this->get_operator_labels();
		$nonce_ajax = wp_create_nonce( 'spgc_ajax' );
		$ajax_url   = admin_url( 'admin-ajax.php' );

		?>
		<div class="wrap" id="spgc-wrap">

		<style>
		/* ── Reset & base ─────────────────────────────────────────── */
		#spgc-wrap *{box-sizing:border-box}
		#spgc-page{
			max-width:980px;
			font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;
			color:#1e293b;
		}

		/* ── Header ───────────────────────────────────────────────── */
		.spgc-header{
			display:flex;align-items:center;justify-content:space-between;
			margin:16px 0 6px;flex-wrap:wrap;gap:12px;
		}
		.spgc-header h1{
			margin:0;font-size:1.35rem;font-weight:700;
			display:flex;align-items:center;gap:10px;color:#0f172a;
		}
		.spgc-badge{
			background:#6366f1;color:#fff;
			border-radius:20px;font-size:.7rem;font-weight:700;
			padding:3px 10px;letter-spacing:.03em;
		}
		.spgc-subtitle{color:#64748b;margin:0 0 20px;font-size:.875rem}

		/* ── Saved notice ─────────────────────────────────────────── */
		.spgc-notice{
			display:flex;align-items:center;gap:8px;
			background:#f0fdf4;border:1px solid #86efac;
			color:#166534;padding:11px 16px;border-radius:8px;
			margin-bottom:18px;font-size:.875rem;font-weight:500;
		}
		.spgc-notice svg{flex-shrink:0}

		/* ── Empty state ──────────────────────────────────────────── */
		.spgc-empty{
			text-align:center;padding:40px 24px;
			border:2px dashed #e2e8f0;border-radius:12px;
			color:#94a3b8;margin-bottom:12px;
		}
		.spgc-empty p{margin:8px 0 0;font-size:.875rem}

		/* ── Rule card ────────────────────────────────────────────── */
		.spgc-rule{
			background:#fff;
			border:1px solid #e2e8f0;
			border-radius:12px;
			padding:18px 20px;
			margin-bottom:10px;
			box-shadow:0 1px 3px rgba(0,0,0,.04);
			transition:box-shadow .15s;
		}
		.spgc-rule:hover{box-shadow:0 4px 12px rgba(0,0,0,.08)}

		/* rule top bar */
		.spgc-rule-topbar{
			display:flex;align-items:center;justify-content:space-between;
			margin-bottom:14px;
		}
		.spgc-rule-num{
			font-size:.7rem;font-weight:700;letter-spacing:.08em;
			text-transform:uppercase;color:#94a3b8;
		}
		.spgc-remove{
			background:none;border:none;cursor:pointer;
			color:#cbd5e1;padding:4px;border-radius:6px;
			display:flex;align-items:center;
			transition:color .15s,background .15s;
		}
		.spgc-remove:hover{color:#ef4444;background:#fef2f2}

		/* rule grid */
		.spgc-rule-grid{
			display:grid;
			grid-template-columns: minmax(160px,1fr) 120px minmax(180px,1.4fr) 28px minmax(180px,1fr);
			gap:10px;
			align-items:end;
		}
		@media(max-width:860px){
			.spgc-rule-grid{grid-template-columns:1fr 1fr;gap:10px}
			.spgc-arrow{display:none}
		}

		/* field */
		.spgc-field{display:flex;flex-direction:column;gap:5px}
		.spgc-field label{
			font-size:.7rem;font-weight:700;letter-spacing:.06em;
			text-transform:uppercase;color:#64748b;
		}

		/* inputs */
		.spgc-field select,
		.spgc-field input[type="number"]{
			height:40px;padding:0 12px;
			border:1.5px solid #e2e8f0;border-radius:8px;
			font-size:.875rem;background:#fff;color:#1e293b;
			width:100%;appearance:none;
			background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%2394a3b8' stroke-width='2.5'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E");
			background-repeat:no-repeat;background-position:right 10px center;
			padding-right:32px;
			transition:border-color .15s,box-shadow .15s;
		}
		.spgc-field input[type="number"]{background-image:none;padding-right:12px}
		.spgc-field select:focus,
		.spgc-field input[type="number"]:focus{
			border-color:#6366f1;outline:none;
			box-shadow:0 0 0 3px rgba(99,102,241,.12);
		}

		/* arrow */
		.spgc-arrow{
			display:flex;align-items:center;justify-content:center;
			padding-bottom:4px;color:#94a3b8;
		}

		/* then pill */
		.spgc-then-label{
			display:inline-flex;align-items:center;gap:4px;
			background:#fef9c3;color:#854d0e;
			font-size:.68rem;font-weight:700;letter-spacing:.06em;
			text-transform:uppercase;padding:2px 8px;border-radius:20px;
			margin-bottom:2px;
		}

		/* ── Select2 overrides ────────────────────────────────────── */
		.spgc-field .select2-container{width:100%!important}
		.spgc-field .select2-container--default .select2-selection--single,
		.spgc-field .select2-container--default .select2-selection--multiple{
			height:auto!important;min-height:40px!important;
			border:1.5px solid #e2e8f0!important;border-radius:8px!important;
			background:#fff!important;padding:2px 6px!important;
		}
		.spgc-field .select2-container--default.select2-container--focus .select2-selection--single,
		.spgc-field .select2-container--default.select2-container--focus .select2-selection--multiple{
			border-color:#6366f1!important;
			box-shadow:0 0 0 3px rgba(99,102,241,.12)!important;outline:none!important;
		}
		.spgc-field .select2-container--default .select2-selection--single .select2-selection__rendered{
			line-height:36px!important;padding-left:6px!important;color:#1e293b!important;font-size:.875rem!important;
		}
		.spgc-field .select2-container--default .select2-selection--single .select2-selection__arrow{
			height:38px!important;right:6px!important;
		}
		.spgc-field .select2-container--default .select2-selection--multiple .select2-selection__choice{
			background:#6366f1!important;border:none!important;color:#fff!important;
			border-radius:6px!important;padding:2px 8px!important;font-size:.78rem!important;margin:3px 3px 3px 0!important;
		}
		.spgc-field .select2-container--default .select2-selection--multiple .select2-selection__choice__remove{
			color:rgba(255,255,255,.7)!important;margin-right:4px!important;
		}
		.spgc-field .select2-container--default .select2-selection--multiple .select2-selection__choice__remove:hover{
			color:#fff!important;
		}
		.spgc-field .select2-container--default .select2-selection--multiple .select2-search__field{
			font-size:.875rem!important;margin-top:4px!important;
		}
		.select2-dropdown{border:1.5px solid #e2e8f0!important;border-radius:10px!important;box-shadow:0 8px 24px rgba(0,0,0,.1)!important;overflow:hidden}
		.select2-results__option{font-size:.875rem!important;padding:8px 12px!important}
		.select2-container--default .select2-results__option--highlighted{background:#6366f1!important}

		/* ── Toolbar ──────────────────────────────────────────────── */
		.spgc-toolbar{
			display:flex;gap:10px;margin-top:18px;align-items:center;
			padding-top:18px;border-top:1px solid #f1f5f9;
		}
		.spgc-btn{
			display:inline-flex;align-items:center;gap:6px;
			padding:10px 20px;border-radius:9px;font-size:.875rem;font-weight:600;
			cursor:pointer;border:none;transition:all .15s;
		}
		.spgc-btn-outline{
			background:#fff;color:#6366f1;
			border:1.5px solid #c7d2fe;
		}
		.spgc-btn-outline:hover{background:#f5f3ff;border-color:#a5b4fc}
		.spgc-btn-primary{
			background:linear-gradient(135deg,#6366f1,#4f46e5);
			color:#fff;box-shadow:0 2px 8px rgba(99,102,241,.35);
		}
		.spgc-btn-primary:hover{background:linear-gradient(135deg,#4f46e5,#4338ca);box-shadow:0 4px 12px rgba(99,102,241,.45)}
		</style>

		<div id="spgc-page">

			<div class="spgc-header">
				<h1>
					<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#6366f1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="4" width="22" height="16" rx="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>
					<?php esc_html_e( 'Payment Rules', 'smart-payment-gateway-control' ); ?>
					<span class="spgc-badge" id="spgc-badge">
						<?php echo esc_html( count( $rules ) ); ?> <?php esc_html_e( 'rules', 'smart-payment-gateway-control' ); ?>
					</span>
				</h1>
			</div>
			<p class="spgc-subtitle">
				<?php esc_html_e( 'Hide payment methods at checkout using IF → THEN rules. Rules are evaluated in order.', 'smart-payment-gateway-control' ); ?>
			</p>

			<?php if ( $saved ) : ?>
			<div class="spgc-notice">
				<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M20 6L9 17l-5-5"/></svg>
				<?php esc_html_e( 'Rules saved successfully.', 'smart-payment-gateway-control' ); ?>
			</div>
			<?php endif; ?>

			<form method="post">
				<?php wp_nonce_field( self::NONCE_ACTION, self::NONCE_NAME ); ?>

				<div id="spgc-rules-list">
				<?php if ( empty( $rules ) ) : ?>
					<div class="spgc-empty" id="spgc-empty-state">
						<svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#cbd5e1" stroke-width="1.5"><rect x="1" y="4" width="22" height="16" rx="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>
						<p><?php esc_html_e( 'No rules yet. Click "Add Rule" to get started.', 'smart-payment-gateway-control' ); ?></p>
					</div>
				<?php endif; ?>

				<?php foreach ( $rules as $i => $rule ) : ?>
					<?php $this->render_rule_card( $i, $rule, $gateways, $categories, $roles, $countries, $cond_types, $op_map, $op_labels ); ?>
				<?php endforeach; ?>
				</div>

				<div class="spgc-toolbar">
					<button type="button" id="spgc-add-btn" class="spgc-btn spgc-btn-outline">
						<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
						<?php esc_html_e( 'Add Rule', 'smart-payment-gateway-control' ); ?>
					</button>
					<button type="submit" class="spgc-btn spgc-btn-primary">
						<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>
						<?php esc_html_e( 'Save Rules', 'smart-payment-gateway-control' ); ?>
					</button>
				</div>

			</form>
		</div><!-- #spgc-page -->

		<script>
		(function($){
			'use strict';

			/* ── Data passed from PHP ── */
			var IDX        = <?php echo (int) count( $rules ); ?>;
			var AJAX_URL   = <?php echo wp_json_encode( $ajax_url ); ?>;
			var SECURITY   = <?php echo wp_json_encode( $nonce_ajax ); ?>;
			var OP_MAP     = <?php echo wp_json_encode( $op_map ); ?>;
			var OP_LABELS  = <?php echo wp_json_encode( $op_labels ); ?>;
			var GATEWAYS   = <?php echo wp_json_encode( $gateways ); ?>;
			var CATEGORIES = <?php echo wp_json_encode( $categories ); ?>;
			var ROLES      = <?php echo wp_json_encode( $roles ); ?>;
			var COUNTRIES  = <?php echo wp_json_encode( $countries ); ?>;
			var COND_TYPES = <?php echo wp_json_encode( $cond_types ); ?>;

			/* ── i18n strings ── */
			var I18N = {
				rule        : <?php echo wp_json_encode( esc_html__( 'Rule', 'smart-payment-gateway-control' ) ); ?>,
				rules       : <?php echo wp_json_encode( esc_html__( 'rules', 'smart-payment-gateway-control' ) ); ?>,
				if_label    : <?php echo wp_json_encode( esc_html__( 'If…', 'smart-payment-gateway-control' ) ); ?>,
				operator    : <?php echo wp_json_encode( esc_html__( 'Operator', 'smart-payment-gateway-control' ) ); ?>,
				value       : <?php echo wp_json_encode( esc_html__( 'Value', 'smart-payment-gateway-control' ) ); ?>,
				then_disable: <?php echo wp_json_encode( esc_html__( 'Then disable', 'smart-payment-gateway-control' ) ); ?>,
				remove      : <?php echo wp_json_encode( esc_html__( 'Remove rule', 'smart-payment-gateway-control' ) ); ?>,
				no_rules    : <?php echo wp_json_encode( esc_html__( 'No rules yet. Click "Add Rule" to get started.', 'smart-payment-gateway-control' ) ); ?>,
				select      : <?php echo wp_json_encode( esc_html__( '— select —', 'smart-payment-gateway-control' ) ); ?>,
				search_prod : <?php echo wp_json_encode( esc_html__( 'Search products…', 'smart-payment-gateway-control' ) ); ?>,
				search_ship : <?php echo wp_json_encode( esc_html__( 'Search shipping methods…', 'smart-payment-gateway-control' ) ); ?>,
			};

			/* ── Escape HTML helper ── */
			function esc(s){ return $('<span>').text(String(s)).html(); }

			/* ── Build <option> lists ── */
			function buildOptions(map, selected){
				var html = '';
				$.each(map, function(k,v){
					html += '<option value="'+esc(k)+'"'+(k===selected?' selected':'')+'>'+esc(v)+'</option>';
				});
				return html;
			}

			function buildOpOptions(ct, sel){
				var ops = OP_MAP[ct] || ['is','is_not'];
				var html = '';
				$.each(ops, function(_,k){
					html += '<option value="'+esc(k)+'"'+(k===sel?' selected':'')+'>'+esc(OP_LABELS[k])+'</option>';
				});
				return html;
			}

			/* ── Build value field HTML ── */
			function buildValueField(i, ct, val){
				var name = 'spgc_rules['+i+'][value]';
				var vals = Array.isArray(val) ? val : (val ? [val] : []);

				if(ct === 'category'){
					var opts='';
					$.each(CATEGORIES, function(slug,lbl){
						var sel = vals.indexOf(slug)>-1 ? ' selected' : '';
						opts += '<option value="'+esc(slug)+'"'+sel+'>'+esc(lbl)+'</option>';
					});
					return '<select name="'+esc(name)+'[]" multiple class="spgc-s2-multi">'+opts+'</select>';
				}
				if(ct === 'product'){
					return '<select name="'+esc(name)+'[]" multiple class="spgc-s2-product"></select>';
				}
				if(ct === 'user_role'){
					var cur = vals[0]||'';
					return '<select name="'+esc(name)+'">'+buildOptions(ROLES,cur)+'</select>';
				}
				if(ct === 'country'){
					var cur = vals[0]||'';
					return '<select name="'+esc(name)+'" class="spgc-s2-country">'+buildOptions(COUNTRIES,cur)+'</select>';
				}
				if(ct === 'shipping_method'){
					var cur = vals[0]||'';
					var opt = cur ? '<option value="'+esc(cur)+'" selected>'+esc(cur)+'</option>' : '';
					return '<select name="'+esc(name)+'" class="spgc-s2-ship">'+opt+'</select>';
				}
				/* numeric: cart_total / quantity */
				var num = vals[0]||'';
				return '<input type="number" name="'+esc(name)+'" value="'+esc(num)+'" min="0" step="0.01" placeholder="0">';
			}

			/* ── Build full rule card HTML ── */
			function buildCard(i){
				var defCt = 'category';
				var gwOpts = '<option value="">'+esc(I18N.select)+'</option>'+buildOptions(GATEWAYS,'');

				return [
					'<div class="spgc-rule" data-index="'+i+'">',
						'<div class="spgc-rule-topbar">',
							'<span class="spgc-rule-num">'+esc(I18N.rule)+' #'+(i+1)+'</span>',
							'<button type="button" class="spgc-remove" title="'+esc(I18N.remove)+'">',
								'<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>',
							'</button>',
						'</div>',
						'<div class="spgc-rule-grid">',

							/* condition type */
							'<div class="spgc-field">',
								'<label>'+esc(I18N.if_label)+'</label>',
								'<select name="spgc_rules['+i+'][condition_type]" class="spgc-ct">'+buildOptions(COND_TYPES,defCt)+'</select>',
							'</div>',

							/* operator */
							'<div class="spgc-field">',
								'<label>'+esc(I18N.operator)+'</label>',
								'<select name="spgc_rules['+i+'][operator]" class="spgc-op">'+buildOpOptions(defCt,'is')+'</select>',
							'</div>',

							/* value */
							'<div class="spgc-field spgc-val-wrap">',
								'<label>'+esc(I18N.value)+'</label>',
								buildValueField(i, defCt, ''),
							'</div>',

							/* arrow */
							'<div class="spgc-arrow">',
								'<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#94a3b8" stroke-width="2"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>',
							'</div>',

							/* gateway */
							'<div class="spgc-field">',
								'<div class="spgc-then-label">',
									'<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="22 8 13.5 16.5 8 11 2 17"/><polyline points="16 8 22 8 22 14"/></svg>',
									'<?php echo esc_js( esc_html__( 'Then disable', 'smart-payment-gateway-control' ) ); ?>',
								'</div>',
								'<select name="spgc_rules['+i+'][gateway]">'+gwOpts+'</select>',
							'</div>',

						'</div>',
					'</div>'
				].join('');
			}

			/* ── Init Select2 on a card ── */
			function initS2(card){
				card.find('.spgc-s2-multi').each(function(){
					if(!$(this).hasClass('select2-hidden-accessible')){
						$(this).select2({ width:'100%', closeOnSelect:false });
					}
				});
				card.find('.spgc-s2-country').each(function(){
					if(!$(this).hasClass('select2-hidden-accessible')){
						$(this).select2({ width:'100%' });
					}
				});
				card.find('.spgc-s2-product').each(function(){
					if(!$(this).hasClass('select2-hidden-accessible')){
						$(this).select2({
							width:'100%', multiple:true, minimumInputLength:2,
							placeholder: I18N.search_prod,
							ajax:{
								url:AJAX_URL, dataType:'json', delay:300,
								data:function(p){return{action:'spgc_search_products',q:p.term,security:SECURITY};},
								processResults:function(d){return{results:d.results};}
							}
						});
					}
				});
				card.find('.spgc-s2-ship').each(function(){
					if(!$(this).hasClass('select2-hidden-accessible')){
						$(this).select2({
							width:'100%', placeholder: I18N.search_ship,
							ajax:{
								url:AJAX_URL, dataType:'json',
								data:function(){return{action:'spgc_search_shipping',security:SECURITY};},
								processResults:function(d){return{results:d.results};}
							}
						});
					}
				});
			}

			/* ── Destroy Select2 in a field ── */
			function destroyS2(wrap){
				wrap.find('select').each(function(){
					try{ if($(this).hasClass('select2-hidden-accessible')){ $(this).select2('destroy'); } }catch(e){}
				});
			}

			/* ── Condition type change → rebuild operator + value ── */
			$(document).on('change','.spgc-ct',function(){
				var card = $(this).closest('.spgc-rule');
				var i    = card.data('index');
				var ct   = $(this).val();

				/* update operators */
				card.find('.spgc-op').html(buildOpOptions(ct,'is'));

				/* rebuild value wrap */
				var vw = card.find('.spgc-val-wrap');
				destroyS2(vw);
				vw.html('<label>'+esc(I18N.value)+'</label>'+buildValueField(i,ct,''));
				initS2(card);
			});

			/* ── Add rule ── */
			$('#spgc-add-btn').on('click',function(){
				$('#spgc-empty-state').remove();
				var card = $(buildCard(IDX));
				$('#spgc-rules-list').append(card);
				initS2(card);
				updateBadge();
				IDX++;
			});

			/* ── Remove rule ── */
			$(document).on('click','.spgc-remove',function(){
				$(this).closest('.spgc-rule').remove();
				if(!$('.spgc-rule').length){
					$('#spgc-rules-list').html(
						'<div class="spgc-empty" id="spgc-empty-state">'+
						'<svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#cbd5e1" stroke-width="1.5"><rect x="1" y="4" width="22" height="16" rx="2"/><line x1="1" y1="10" x2="23" y2="10"/></svg>'+
						'<p>'+esc(I18N.no_rules)+'</p></div>'
					);
				}
				updateBadge();
			});

			function updateBadge(){
				$('#spgc-badge').text($('.spgc-rule').length+' '+I18N.rules);
			}

			/* ── Init Select2 on saved rules ── */
			$('.spgc-rule').each(function(){ initS2($(this)); });

		})(jQuery);
		</script>

		</div><!-- #spgc-wrap -->
		<?php
	}

	/* ── Render one saved rule card (PHP side) ─────────────────────── */

	private function render_rule_card( $i, $rule, $gateways, $categories, $roles, $countries, $cond_types, $op_map, $op_labels ) {
		$ct  = isset( $rule['condition_type'] ) ? $rule['condition_type'] : 'category';
		$op  = isset( $rule['operator'] )       ? $rule['operator']       : 'is';
		$val = isset( $rule['value'] )          ? $rule['value']          : '';
		$gw  = isset( $rule['gateway'] )        ? $rule['gateway']        : '';
		$ops = isset( $op_map[ $ct ] )          ? $op_map[ $ct ]          : array( 'is', 'is_not' );
		?>
		<div class="spgc-rule" data-index="<?php echo (int) $i; ?>">

			<div class="spgc-rule-topbar">
				<span class="spgc-rule-num">
					<?php esc_html_e( 'Rule', 'smart-payment-gateway-control' ); ?> #<?php echo (int) $i + 1; ?>
				</span>
				<button type="button" class="spgc-remove" title="<?php esc_attr_e( 'Remove rule', 'smart-payment-gateway-control' ); ?>">
					<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
				</button>
			</div>

			<div class="spgc-rule-grid">

				<!-- Condition type -->
				<div class="spgc-field">
					<label><?php esc_html_e( 'If…', 'smart-payment-gateway-control' ); ?></label>
					<select name="spgc_rules[<?php echo (int) $i; ?>][condition_type]" class="spgc-ct">
						<?php foreach ( $cond_types as $key => $label ) : ?>
							<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $ct, $key ); ?>><?php echo esc_html( $label ); ?></option>
						<?php endforeach; ?>
					</select>
				</div>

				<!-- Operator -->
				<div class="spgc-field">
					<label><?php esc_html_e( 'Operator', 'smart-payment-gateway-control' ); ?></label>
					<select name="spgc_rules[<?php echo (int) $i; ?>][operator]" class="spgc-op">
						<?php foreach ( $ops as $ok ) : ?>
							<option value="<?php echo esc_attr( $ok ); ?>" <?php selected( $op, $ok ); ?>>
								<?php echo esc_html( isset( $op_labels[ $ok ] ) ? $op_labels[ $ok ] : $ok ); ?>
							</option>
						<?php endforeach; ?>
					</select>
				</div>

				<!-- Value -->
				<div class="spgc-field spgc-val-wrap">
					<label><?php esc_html_e( 'Value', 'smart-payment-gateway-control' ); ?></label>
					<?php $this->render_value_input( $i, $ct, $val, $categories, $roles, $countries ); ?>
				</div>

				<!-- Arrow -->
				<div class="spgc-arrow">
					<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#94a3b8" stroke-width="2"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
				</div>

				<!-- Gateway -->
				<div class="spgc-field">
					<div class="spgc-then-label">
						<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="22 8 13.5 16.5 8 11 2 17"/><polyline points="16 8 22 8 22 14"/></svg>
						<?php esc_html_e( 'Then disable', 'smart-payment-gateway-control' ); ?>
					</div>
					<select name="spgc_rules[<?php echo (int) $i; ?>][gateway]">
						<option value=""><?php esc_html_e( '— select —', 'smart-payment-gateway-control' ); ?></option>
						<?php foreach ( $gateways as $gid => $gtitle ) : ?>
							<option value="<?php echo esc_attr( $gid ); ?>" <?php selected( $gw, $gid ); ?>><?php echo esc_html( $gtitle ); ?></option>
						<?php endforeach; ?>
					</select>
				</div>

			</div><!-- .spgc-rule-grid -->
		</div>
		<?php
	}

	private function render_value_input( $i, $ct, $val, $categories, $roles, $countries ) {
		$name = 'spgc_rules[' . (int) $i . '][value]';
		$vals = (array) $val;

		switch ( $ct ) {
			case 'category':
				echo '<select name="' . esc_attr( $name ) . '[]" multiple class="spgc-s2-multi">';
				foreach ( $categories as $slug => $label ) {
					$selected = in_array( $slug, $vals, true ) ? ' selected="selected"' : '';
					echo '<option value="' . esc_attr( $slug ) . '"' . $selected . '>' . esc_html( $label ) . '</option>'; // phpcs:ignore
				}
				echo '</select>';
				break;

			case 'product':
				echo '<select name="' . esc_attr( $name ) . '[]" multiple class="spgc-s2-product">';
				foreach ( $vals as $pid ) {
					$pid = absint( $pid );
					$p   = $pid ? wc_get_product( $pid ) : null;
					if ( $p ) {
						echo '<option value="' . esc_attr( $pid ) . '" selected="selected">' . esc_html( wp_strip_all_tags( $p->get_formatted_name() ) ) . '</option>';
					}
				}
				echo '</select>';
				break;

			case 'user_role':
				$current = reset( $vals );
				echo '<select name="' . esc_attr( $name ) . '">';
				foreach ( $roles as $slug => $label ) {
					$selected = ( $current === $slug ) ? ' selected="selected"' : '';
					echo '<option value="' . esc_attr( $slug ) . '"' . $selected . '>' . esc_html( $label ) . '</option>'; // phpcs:ignore
				}
				echo '</select>';
				break;

			case 'country':
				$current = reset( $vals );
				echo '<select name="' . esc_attr( $name ) . '" class="spgc-s2-country">';
				foreach ( $countries as $code => $cname ) {
					$selected = ( $current === $code ) ? ' selected="selected"' : '';
					echo '<option value="' . esc_attr( $code ) . '"' . $selected . '>' . esc_html( $cname ) . '</option>'; // phpcs:ignore
				}
				echo '</select>';
				break;

			case 'shipping_method':
				$saved = reset( $vals );
				echo '<select name="' . esc_attr( $name ) . '" class="spgc-s2-ship">';
				if ( $saved ) {
					echo '<option value="' . esc_attr( $saved ) . '" selected="selected">' . esc_html( $saved ) . '</option>';
				}
				echo '</select>';
				break;

			case 'cart_total':
			case 'quantity':
			default:
				$num = reset( $vals );
				echo '<input type="number" name="' . esc_attr( $name ) . '" value="' . esc_attr( (string) $num ) . '" min="0" step="0.01" placeholder="0">';
				break;
		}
	}

	/* =========================================================================
	 * SAVE
	 * ====================================================================== */

	private function save_rules() {
		if (
			! isset( $_POST[ self::NONCE_NAME ] ) ||
			! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST[ self::NONCE_NAME ] ) ), self::NONCE_ACTION )
		) {
			return;
		}

		if ( empty( $_POST['spgc_rules'] ) || ! is_array( $_POST['spgc_rules'] ) ) {
			update_option( self::OPTION_KEY, array() );
			return;
		}

		$post_data     = wp_unslash( $_POST );
		$raw           = (array) $post_data['spgc_rules'];
		$allowed_types = array_keys( $this->get_condition_types() );
		$allowed_ops   = array( 'is', 'is_not', 'gt', 'gte', 'lt', 'lte' );
		$clean         = array();

		foreach ( $raw as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}
			$ct  = sanitize_key( isset( $row['condition_type'] ) ? $row['condition_type'] : '' );
			$op  = sanitize_key( isset( $row['operator'] )       ? $row['operator']       : 'is' );
			$gw  = sanitize_key( isset( $row['gateway'] )        ? $row['gateway']        : '' );

			if ( ! in_array( $ct, $allowed_types, true ) || ! in_array( $op, $allowed_ops, true ) || ! $gw ) {
				continue;
			}
			$value = $this->sanitize_value( $ct, isset( $row['value'] ) ? $row['value'] : '' );
			if ( '' === $value || array() === $value ) {
				continue;
			}
			$clean[] = array(
				'condition_type' => $ct,
				'operator'       => $op,
				'value'          => $value,
				'gateway'        => $gw,
			);
		}

		update_option( self::OPTION_KEY, $clean );
	}

	private function sanitize_value( $type, $value ) {
		switch ( $type ) {
			case 'cart_total':
			case 'quantity':
				$v = is_array( $value ) ? reset( $value ) : $value;
				return (string) abs( (float) $v );
			case 'product':
				return array_values( array_filter( array_map( 'absint', (array) $value ) ) );
			case 'category':
				return array_values( array_filter( array_map( 'sanitize_text_field', (array) $value ) ) );
			case 'user_role':
				$v = is_array( $value ) ? reset( $value ) : $value;
				return sanitize_key( $v );
			case 'shipping_method':
				$v = is_array( $value ) ? reset( $value ) : $value;
				return sanitize_text_field( $v );
			case 'country':
				$v = is_array( $value ) ? reset( $value ) : $value;
				$v = strtoupper( sanitize_text_field( $v ) );
				return ( 2 === strlen( $v ) ) ? $v : '';
			default:
				$v = is_array( $value ) ? reset( $value ) : $value;
				return sanitize_text_field( $v );
		}
	}

	/* =========================================================================
	 * FRONT-END FILTERING
	 * ====================================================================== */

	public function filter_gateways( $available_gateways ) {
		if ( is_admin() || ! function_exists( 'WC' ) || ! WC()->cart ) {
			return $available_gateways;
		}
		$rules = $this->get_rules();
		foreach ( $rules as $rule ) {
			if ( isset( $available_gateways[ $rule['gateway'] ] ) && $this->evaluate( $rule ) ) {
				unset( $available_gateways[ $rule['gateway'] ] );
			}
		}
		return $available_gateways;
	}

	private function evaluate( $rule ) {
		$ct  = isset( $rule['condition_type'] ) ? $rule['condition_type'] : '';
		$op  = isset( $rule['operator'] )       ? $rule['operator']       : 'is';
		$val = isset( $rule['value'] )          ? $rule['value']          : '';

		switch ( $ct ) {
			case 'category':
				return $this->eval_category( (array) $val, $op );
			case 'product':
				return $this->eval_product( (array) $val, $op );
			case 'cart_total':
				return $this->eval_number( (float) WC()->cart->get_cart_contents_total(), $op, (float) $val );
			case 'user_role':
				return $this->eval_role( (string) $val, $op );
			case 'shipping_method':
				return $this->eval_shipping( (string) $val, $op );
			case 'country':
				return $this->eval_country( (string) $val, $op );
			case 'quantity':
				return $this->eval_number( (float) WC()->cart->get_cart_contents_count(), $op, (float) $val );
		}
		return false;
	}

	private function eval_category( $slugs, $op ) {
		$found = false;
		foreach ( WC()->cart->get_cart() as $item ) {
			$pid = absint( isset( $item['product_id'] ) ? $item['product_id'] : 0 );
			if ( $pid && array_intersect( $slugs, $this->product_cat_slugs( $pid ) ) ) {
				$found = true; break;
			}
		}
		return 'is_not' === $op ? ! $found : $found;
	}

	private function eval_product( $ids, $op ) {
		$ids = array_map( 'intval', $ids );
		$found = false;
		foreach ( WC()->cart->get_cart() as $item ) {
			if ( in_array( (int) $item['product_id'], $ids, true ) ) { $found = true; break; }
		}
		return 'is_not' === $op ? ! $found : $found;
	}

	private function eval_number( $actual, $op, $compare ) {
		switch ( $op ) {
			case 'gt':  return $actual > $compare;
			case 'gte': return $actual >= $compare;
			case 'lt':  return $actual < $compare;
			case 'lte': return $actual <= $compare;
			case 'is':  return abs( $actual - $compare ) < 0.001;
			case 'is_not': return abs( $actual - $compare ) >= 0.001;
		}
		return false;
	}

	private function eval_role( $value, $op ) {
		$has = ( 'guest' === $value ) ? ! is_user_logged_in() : in_array( $value, (array) wp_get_current_user()->roles, true );
		return 'is_not' === $op ? ! $has : $has;
	}

	private function eval_shipping( $value, $op ) {
		$chosen = WC()->session ? (array) WC()->session->get( 'chosen_shipping_methods' ) : array();
		$has = in_array( $value, $chosen, true );
		return 'is_not' === $op ? ! $has : $has;
	}

	private function eval_country( $value, $op ) {
		$country = WC()->customer ? strtoupper( (string) WC()->customer->get_billing_country() ) : '';
		$has = ( $country === strtoupper( $value ) );
		return 'is_not' === $op ? ! $has : $has;
	}

	/* =========================================================================
	 * DATA HELPERS
	 * ====================================================================== */

	public function get_rules() {
		return (array) get_option( self::OPTION_KEY, array() );
	}

	private function product_cat_slugs( $pid ) {
		$slugs = array();
		$terms = get_the_terms( $pid, 'product_cat' );
		if ( ! is_array( $terms ) ) return $slugs;
		foreach ( $terms as $term ) {
			$slugs[] = $term->slug;
			foreach ( get_ancestors( $term->term_id, 'product_cat' ) as $anc_id ) {
				$anc = get_term( $anc_id, 'product_cat' );
				if ( $anc instanceof WP_Term ) $slugs[] = $anc->slug;
			}
		}
		return array_unique( $slugs );
	}

	private function get_gateway_options() {
		$out = array();
		foreach ( WC()->payment_gateways()->payment_gateways() as $id => $gw ) {
			$out[ $id ] = $gw->get_title() ? $gw->get_title() : $id;
		}
		return $out;
	}

	private function get_category_options() {
		$out = array();
		$terms = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false, 'orderby' => 'name' ) );
		if ( is_array( $terms ) ) {
			foreach ( $terms as $t ) $out[ $t->slug ] = $t->name;
		}
		return $out;
	}

	private function get_role_options() {
		global $wp_roles;
		$out = array( 'guest' => esc_html__( 'Guest (not logged in)', 'smart-payment-gateway-control' ) );
		foreach ( $wp_roles->roles as $slug => $data ) {
			$out[ $slug ] = translate_user_role( $data['name'] );
		}
		return $out;
	}

	private function get_country_options() {
		return WC()->countries ? WC()->countries->get_countries() : array();
	}

	private function get_condition_types() {
		return array(
			'category'        => esc_html__( 'Product Category', 'smart-payment-gateway-control' ),
			'product'         => esc_html__( 'Specific Product', 'smart-payment-gateway-control' ),
			'cart_total'      => esc_html__( 'Cart Total', 'smart-payment-gateway-control' ),
			'user_role'       => esc_html__( 'User Role', 'smart-payment-gateway-control' ),
			'shipping_method' => esc_html__( 'Shipping Method', 'smart-payment-gateway-control' ),
			'country'         => esc_html__( 'Billing Country', 'smart-payment-gateway-control' ),
			'quantity'        => esc_html__( 'Order Quantity', 'smart-payment-gateway-control' ),
		);
	}

	private function get_operators_map() {
		return array(
			'category'        => array( 'is', 'is_not' ),
			'product'         => array( 'is', 'is_not' ),
			'cart_total'      => array( 'gt', 'gte', 'lt', 'lte', 'is', 'is_not' ),
			'user_role'       => array( 'is', 'is_not' ),
			'shipping_method' => array( 'is', 'is_not' ),
			'country'         => array( 'is', 'is_not' ),
			'quantity'        => array( 'gt', 'gte', 'lt', 'lte', 'is', 'is_not' ),
		);
	}

	private function get_operator_labels() {
		return array(
			'is'     => esc_html__( 'is', 'smart-payment-gateway-control' ),
			'is_not' => esc_html__( 'is not', 'smart-payment-gateway-control' ),
			'gt'     => '>',
			'gte'    => '>=',
			'lt'     => '<',
			'lte'    => '<=',
		);
	}
}

endif; // class_exists

add_action( 'plugins_loaded', static function () {
	if ( class_exists( 'WooCommerce' ) ) {
		SPGC_Plugin::get_instance();
	}
}, 20 );
