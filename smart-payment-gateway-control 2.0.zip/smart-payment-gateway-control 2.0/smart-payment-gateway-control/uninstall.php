<?php
/**
 * Uninstall handler — runs when the plugin is deleted via the WordPress admin.
 *
 * Removes all plugin data from the database.
 *
 * @package DisablePaymentByProduct
 */

// Security: only run when WordPress triggers uninstall.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

// Remove the rules option.
delete_option( 'spgc_rules' );
